from django.apps import AppConfig


class PharmacyConfig(AppConfig):
    name = 'pharmacy'
