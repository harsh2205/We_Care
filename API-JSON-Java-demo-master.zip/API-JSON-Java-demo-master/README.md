# API and JSON in Java Demo

This is a demo for ICSI 518 software engineering course offered in Fall 2017 at University at Albany SUNY. 

This is a plain Java object, it uses Maven to manage dependencies. Download and import it into Eclipse to run.

The main code is in CallAPI.java. It demonstrates how to use JAX-RS (Jersey) to call an RESTful API and get the JSON data. It then use Jackson to read properties from the JSON data. Feel free to copy code from here to your term project.  
